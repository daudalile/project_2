from django.contrib import admin
from .models import applications
# Register your models here.
admin.site.register(applications)